package w14sh2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q1 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/jdbc","","");
		
		Statement stmt=conn.createStatement();
		stmt.execute("create table EmployeeTable(empid int,birthday string,f_name string,l_name string,gender varchar(5),work_day string) 
		ROW FORMAT DELIMITED FIELDS TERMINATED BY ','");
		
		System.out.println("Table for Employee is created Successfully");
		
		
		Statement stmt2=conn.createStatement();
		stmt2.execute("create table salaryTable(empid int,salary string,start_date string,end_date string) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','");
		
		System.out.println("Table for Salary Created Successfully");
		conn.close();
	}
}