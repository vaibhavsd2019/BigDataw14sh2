package w14sh2;

import java.sql.Connnection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Q10 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		
		ResultSet rSet = stmt.executeQuery("select Year,sum(Total_Medals) from olympic where Country='India' Group by Year");
		System.out.println("Year ---- Medals");
		
		while(rSet.next()){
			int YearN=rSet.getInt(1);
			String MedalsV=rSet.getString(2);
			System.out.println(YearN+" ----  "+MedalsV);
		}
	}
}