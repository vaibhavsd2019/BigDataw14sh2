package w14sh2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Q8 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("org.apache.hive.jdbc.HiveDriver");
		Connection conn= DriverManager.getconnnection("jdbc:hive2://localhost:10000/default","","");
		
		Statement stmt=conn.createStatement();
		stmt.execute("create table bucketTable(Name string,Age Int,Country string,Year int, Date string,Sport string,
		Gold int,Silver int, Bronze int, Total_Medals int) clustered by(Country) into 5 buckets 
		ROW FORMAT DELIMITED 
		FIELDS TERMINATED BY '\t'");
		
		System.out.println("Olympic table partition succesfull");
		
		Statement stmt2=conn.createStatement();
		stmt2.execute("insert overwrite table bucketTable select Name, Age, Country, Year, Date, Sport, Gold,
		Silver, Bronze, Total_Medals from olympic;
		
		System.out.println("Data loaded successfully");
		conn.close();
	}
}